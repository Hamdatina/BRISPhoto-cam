# BRIS Photo Helper

Prototype Android app intended to act as an `ACTION_IMAGE_CAPTURE` provider.

## What it does

When another application launches Android's camera intent, this app can appear as a camera option. Instead of taking a new photo, it opens the Android document picker and lets the user select an existing image.

If the calling application supplies `MediaStore.EXTRA_OUTPUT`, the selected image is copied into that destination URI and the activity returns `RESULT_OK`.

## Important limitation

This works only when the calling application uses the standard Android camera intent contract (`ACTION_IMAGE_CAPTURE`) or a compatible implementation.

If BRISPOT uses an embedded/custom camera that does not launch an external `ACTION_IMAGE_CAPTURE` activity, this app will not replace that camera.

## Build

Open this folder in Android Studio and let Gradle sync.

Then:
- Build > Make Project
- Build > Build APK(s)

The debug APK will normally be under:
`app/build/outputs/apk/debug/app-debug.apk`

## Testing

1. Install the APK.
2. Open an application that asks Android for an external camera.
3. Choose `BRIS Photo Helper` if Android presents a camera chooser.
4. Select an existing photo.
5. Confirm that the calling application receives the image.

Do not use this application to misrepresent when/where a photograph was actually taken. It is intended as a workflow helper for images you are authorized to use.