package id.hamdariyadi.brisphotohelper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CameraActivity : Activity() {

    private val PICK_IMAGE = 1001
    private var outputUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // BRISPOT/another caller may supply the destination URI through EXTRA_OUTPUT.
        outputUri = intent.getParcelableExtra(MediaStore.EXTRA_OUTPUT)

        showPickerScreen()
    }

    private fun showPickerScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "BRIS Photo Helper"
            textSize = 26f
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Pilih foto yang sudah ada di galeri"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 30)
        }

        val pick = Button(this).apply {
            text = "PILIH FOTO"
            setOnClickListener { openGallery() }
        }

        val cancel = Button(this).apply {
            text = "BATAL"
            setOnClickListener { setResult(Activity.RESULT_CANCELED); finish() }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(pick)
        root.addView(cancel)
        setContentView(root)
    }

    private fun openGallery() {
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(picker, PICK_IMAGE)
    }

    @Deprecated("Using the platform activity result API for broad Android compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != PICK_IMAGE || resultCode != Activity.RESULT_OK) return

        val selected = data?.data
        if (selected == null) {
            Toast.makeText(this, "Foto tidak ditemukan", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // If the caller supplied EXTRA_OUTPUT, write the selected image into it.
            // This is the normal contract expected by camera callers.
            val destination = outputUri
            if (destination != null) {
                copyUriToUri(selected, destination)
                val result = Intent()
                result.putExtra("data", null as android.graphics.Bitmap?)
                setResult(Activity.RESULT_OK, result)
            } else {
                // Fallback for callers that don't provide EXTRA_OUTPUT:
                // return the selected content URI directly.
                val result = Intent().apply { data = selected }
                setResult(Activity.RESULT_OK, result)
            }
            finish()
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Gagal mengirim foto: ${e.message ?: "error"}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun copyUriToUri(source: Uri, destination: Uri) {
        val resolver = contentResolver
        resolver.openInputStream(source).use { input ->
            requireNotNull(input) { "Tidak bisa membaca foto sumber" }
            resolver.openOutputStream(destination, "w").use { output ->
                requireNotNull(output) { "Tidak bisa menulis ke lokasi tujuan" }
                input.copyTo(output)
                output.flush()
            }
        }
    }
}