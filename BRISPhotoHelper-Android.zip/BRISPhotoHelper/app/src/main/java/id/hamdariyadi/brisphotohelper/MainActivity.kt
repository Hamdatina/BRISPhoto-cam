package id.hamdariyadi.brisphotohelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "BRIS Photo Helper"
            textSize = 28f
        }

        val info = TextView(this).apply {
            text = """
                Aplikasi ini dapat dipanggil sebagai kamera oleh aplikasi lain.

                Saat BRISPOT meminta foto, pilih "BRIS Photo Helper" sebagai kamera.
                Anda kemudian dapat memilih foto yang sudah tersimpan di galeri.
            """.trimIndent()
            textSize = 17f
            setPadding(0, 32, 0, 32)
        }

        val openGallery = Button(this).apply {
            text = "Pilih Foto dari Galeri"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                })
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(openGallery)
        setContentView(layout)
    }
}